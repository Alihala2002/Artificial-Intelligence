import tkinter as tk
from tkinter import ttk
import joblib
import numpy as np
import pandas as pd

preprocessor = joblib.load('sklearn_models/preprocessor.joblib')
dt_model = joblib.load('sklearn_models/decision_tree_model.model')
nb_model = joblib.load('sklearn_models/naive_bayes_model.model')
ann_model = joblib.load('sklearn_models/ann_model.model')
rf_model = joblib.load('sklearn_models/random_forest_model.model')


def predict_loan_status(): ###model prediction
    inputs = [gender.get(), married.get(), dependents.get(), education.get(),
              self_employed.get(), applicant_income.get(), coapplicant_income.get(),
              loan_amount.get(), loan_term.get(), credit_history.get(), property_area.get()]
    
    input_data = pd.DataFrame([inputs], columns=['Gender', 'Married', 'Dependents', 'Education',
                                             'Self_Employed', 'ApplicantIncome', 'CoapplicantIncome',
                                             'LoanAmount', 'Loan_Amount_Term', 'Credit_History',
                                             'Property_Area'])
    X_input_preprocessed = preprocessor.transform(input_data)
    
    
    dt_prediction = dt_model.predict(X_input_preprocessed)
    nb_prediction = nb_model.predict(X_input_preprocessed)
    ann_prediction = ann_model.predict(X_input_preprocessed)
    rf_prediction = rf_model.predict(X_input_preprocessed)

    dt_status.set(f"Decision Tree: {'Approved' if dt_prediction[0] == 'Y' else 'Not Approved'}")
    nb_status.set(f"Naive Bayes: {'Approved' if nb_prediction[0] == 'Y' else 'Not Approved'}")
    ann_status.set(f"ANN: {'Approved' if ann_prediction[0] == 'Y' else 'Not Approved'}")
    rf_status.set(f"Random Forest: {'Approved' if rf_prediction[0] == 'Y' else 'Not Approved'}")


root = tk.Tk()
root.title("Loan Prediction App")


gender = tk.StringVar()
married = tk.StringVar()
dependents = tk.StringVar()
education = tk.StringVar()
self_employed = tk.StringVar()
applicant_income = tk.StringVar()
coapplicant_income = tk.StringVar()
loan_amount = tk.StringVar()
loan_term = tk.StringVar()
credit_history = tk.StringVar()
property_area = tk.StringVar()

# Define variables for the prediction results
dt_status = tk.StringVar()
nb_status = tk.StringVar()
ann_status = tk.StringVar()
rf_status = tk.StringVar()

# Create dropdowns, labels, and entries for all inputs
ttk.Label(root, text="Gender").grid(column=0, row=0)
gender_cb = ttk.Combobox(root, textvariable=gender, values=["Male", "Female"])
gender_cb.grid(column=1, row=0)

ttk.Label(root, text="Gender").grid(column=0, row=0)
gender_cb = ttk.Combobox(root, textvariable=gender, values=["Male", "Female"])
gender_cb.grid(column=1, row=0)

ttk.Label(root, text="Married").grid(column=0, row=1)
married_cb = ttk.Combobox(root, textvariable=married, values=["Yes", "No"])
married_cb.grid(column=1, row=1)

ttk.Label(root, text="Dependents").grid(column=0, row=2)
dependents_cb = ttk.Combobox(root, textvariable=dependents, values=["0", "1", "2", "3+"])
dependents_cb.grid(column=1, row=2)

ttk.Label(root, text="Education").grid(column=0, row=3)
education_cb = ttk.Combobox(root, textvariable=education, values=["Graduate", "Not Graduate"])
education_cb.grid(column=1, row=3)

ttk.Label(root, text="Self Employed").grid(column=0, row=4)
self_employed_cb = ttk.Combobox(root, textvariable=self_employed, values=["Yes", "No"])
self_employed_cb.grid(column=1, row=4)

ttk.Label(root, text="Applicant Income").grid(column=0, row=5)
applicant_income_entry = ttk.Entry(root, textvariable=applicant_income)
applicant_income_entry.grid(column=1, row=5)

ttk.Label(root, text="Coapplicant Income").grid(column=0, row=6)
coapplicant_income_entry = ttk.Entry(root, textvariable=coapplicant_income)
coapplicant_income_entry.grid(column=1, row=6)

ttk.Label(root, text="Loan Amount").grid(column=0, row=7)
loan_amount_entry = ttk.Entry(root, textvariable=loan_amount)
loan_amount_entry.grid(column=1, row=7)

ttk.Label(root, text="Loan Term").grid(column=0, row=8)
loan_term_entry = ttk.Entry(root, textvariable=loan_term)
loan_term_entry.grid(column=1, row=8)

ttk.Label(root, text="Credit History").grid(column=0, row=9)
credit_history_cb = ttk.Combobox(root, textvariable=credit_history, values=["1", "0"])
credit_history_cb.grid(column=1, row=9)

ttk.Label(root, text="Property Area").grid(column=0, row=10)
property_area_cb = ttk.Combobox(root, textvariable=property_area, values=["Urban", "Semiurban", "Rural"])
property_area_cb.grid(column=1, row=10)


predict_button = ttk.Button(root, text="Check the prediction", command=predict_loan_status)
predict_button.grid(column=1, row=11)

ttk.Label(root, textvariable=dt_status).grid(column=2, row=0)
ttk.Label(root, textvariable=nb_status).grid(column=2, row=1)
ttk.Label(root, textvariable=ann_status).grid(column=2, row=2)
ttk.Label(root, textvariable=rf_status).grid(column=2, row=3)


root.mainloop()