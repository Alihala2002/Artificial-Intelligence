import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib


# train_df = pd.read_csv('Dataset/loan-train.csv')

# train_df.drop('Loan_ID', axis=1, inplace=True)### drop becuase no needed independent variable

# X = train_df.drop('Loan_Status', axis=1)
# y = train_df['Loan_Status'] ### target value

# # Identifying categorical and numerical columns
# categorical_cols = X.select_dtypes(include=['object']).columns
# numerical_cols = X.select_dtypes(include=['int64', 'float64']).columns

# numerical_transformer = SimpleImputer(strategy='median')

# # Preprocessing for categorical data
# categorical_transformer = Pipeline(steps=[
#     ('imputer', SimpleImputer(strategy='most_frequent')),
#     ('onehot', OneHotEncoder(handle_unknown='ignore'))
# ])

# preprocessor = ColumnTransformer(
#     transformers=[
#         ('num', numerical_transformer, numerical_cols),
#         ('cat', categorical_transformer, categorical_cols)
#     ])

# X_preprocessed = preprocessor.fit_transform(X)
# joblib.dump(preprocessor, 'sklearn_models/preprocessor.joblib')
# #dataset splitting
# X_train, X_val, y_train, y_val = train_test_split(X_preprocessed, y, test_size=0.2, random_state=0)

# print(X_train.shape, X_val.shape)


# #### Define all models #####
# dt_model = DecisionTreeClassifier(random_state=0)
# ann_model = MLPClassifier(random_state=1, max_iter=300)
# nb_model = GaussianNB()
# rf_model = RandomForestClassifier(random_state=0)

# ### Train all models ####
# dt_model.fit(X_train, y_train)
# ann_model.fit(X_train, y_train)
# nb_model.fit(X_train, y_train)
# rf_model.fit(X_train, y_train)


# ##### Making predictions all models
# dt_pred = dt_model.predict(X_val)
# ann_pred = ann_model.predict(X_val)
# nb_pred = nb_model.predict(X_val)
# rf_pred = rf_model.predict(X_val)


# ##### Model accuracy Calculation ########
# dt_accuracy = accuracy_score(y_val, dt_pred) #decision tree
# ann_accuracy = accuracy_score(y_val, ann_pred) #ann 
# nb_accuracy = accuracy_score(y_val, nb_pred) #naive_bayes
# rf_accuracy = accuracy_score(y_val, rf_pred) #random forest

# # Save all models
# joblib.dump(dt_model, 'sklearn_models/decision_tree_model.model')
# joblib.dump(ann_model, 'sklearn_models/ann_model.model')
# joblib.dump(nb_model, 'sklearn_models/naive_bayes_model.model')
# joblib.dump(rf_model, 'sklearn_models/random_forest_model.model')

# #### print all models accuracy #####
# print("Decision Tree accuracy:",dt_accuracy)
# print("ANN accuracy:",ann_accuracy)
# print("Naive Bayes accuracy:",nb_accuracy)
# print("Random Forest accuracy:",rf_accuracy)



# from sklearn.externals import joblib
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer

preprocessor = joblib.load('sklearn_models/preprocessor.joblib')

# Load the models
dt_model = joblib.load('sklearn_models/decision_tree_model.model')
ann_model = joblib.load('sklearn_models/ann_model.model')
nb_model = joblib.load('sklearn_models/naive_bayes_model.model')
rf_model = joblib.load('sklearn_models/random_forest_model.model')

user_input = {
    'Gender': 'Male',
    'Married': 'No',
    'Dependents': '0',
    'Education': 'Graduate',
    'Self_Employed': 'No',
    'ApplicantIncome': 5000,
    'CoapplicantIncome': 0,
    'LoanAmount': 120,
    'Loan_Amount_Term': 360,
    'Credit_History': 1,
    'Property_Area': 'Urban'
}

# Convert the user input into a DataFrame
input_df = pd.DataFrame([user_input])

X_input_preprocessed = preprocessor.transform(input_df)

# Make predictions with each model
dt_pred_input = dt_model.predict(X_input_preprocessed)
ann_pred_input = ann_model.predict(X_input_preprocessed)
nb_pred_input = nb_model.predict(X_input_preprocessed)
rf_pred_input = rf_model.predict(X_input_preprocessed)

# Output the predictions
print("Decision Tree Prediction:", dt_pred_input[0])
print("ANN Prediction:", ann_pred_input[0])
print("Naive Bayes Prediction:", nb_pred_input[0])
print("Random Forest Prediction:", rf_pred_input[0])